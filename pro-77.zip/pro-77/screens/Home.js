import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  Image,
  Button,
  TouchableOpacity,
  ImageBackground,
} from 'react-native';

export default class Home extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <ImageBackground
          source={require('../assets/stars.gif')}
          style={styles.backgroundImg}>
          <View style={styles.title}>
            <Image
              source={require('../assets/main-icon.png')}
              style={styles.iconImg3}
            />
           <Text style={styles.titleText}>Stellar App</Text>
          </View>
          <TouchableOpacity
            style={styles.button}
            onPress={() => this.props.navigation.navigate('SpaceCrafts')}>
            <Text style={styles.routeText}>SpaceCrafts</Text>
            <Text style={styles.dgbg2}>1</Text>
            <Image
              source={require('../assets/spacecraft.png')}
              style={styles.iconImg2}
            />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={() => this.props.navigation.navigate('DailyPic')}>
            <Text style={styles.routeText}>DailyPic</Text>
            <Text style={styles.dgbg}>2</Text>
            <Image
              source={require('../assets/daily_pictures.png')}
              style={styles.iconImg}
            />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={() => this.props.navigation.navigate('StarMap')}>
            <Text style={styles.routeText}>StarMap</Text>
            <Text style={styles.dgbg}>3</Text>
            <Image
              source={require('../assets/star_map.png')}
              style={styles.iconImg}
            />
          </TouchableOpacity>
        </ImageBackground>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backgroundImg: {
    flex: 1,
    resizeMode: 'cover',
    width: '100%',
  },
  title: {
    flex: 0.15,
    justifyContent: 'center',
    alignContent: 'center',
  },
  titleText: {
    fontSize: 40,
    fontWeight: 'bold',
    color: 'white',
  },
  iconImg: {
    position: 'absolute',
    height: 50,
    width: 100,
    right: 130,
    top: -0,
    resizeMode: 'contain',
  },
  button: {
    
    flex: 0.25,
    marginLeft: 50,
    marginRight: 50,
    marginTop: 70,
    backgroundColor: '#FFFAFA',
    borderRadius: 35,
  },
  routeText: {
    fontSize: 30,
    color: 'black',
    fontWeight: 'bold',
    marginTop: 50,
    paddingLeft: 20,
  },
  dgbg: {
    position: 'absolute',
    fontSize: 60,
    color: 'red',
    bottom: -15,
    paddingLeft: 150,
    zIndex: -1,
  },
    iconImg2: {
    position: 'absolute',
    height: 50,
    width: 85,
    right: 120,
    top: -1,
    resizeMode: 'contain',
  },
  iconImg3: {
    position: 'absolute',
    height: 200,
    width: 200,
    right: 0,
    top: -20,
    resizeMode: 'contain',
  },
  dgbg2: {
    position: 'absolute',
    fontSize: 60,
    color: 'red',
    bottom: -15,
    paddingLeft: 180,
    zIndex: -1,
  },

});
