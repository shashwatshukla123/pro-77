import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import StarMap from './screens/StarMap';
import DailyPic from './screens/DailyPic';
import SpaceCrafts from './screens/SpaceCrafts';
import Home from './screens/Home';

const Stack = createStackNavigator();


export default class App extends React.Component{
  render(){
    return(
      <NavigationContainer>
      <Stack.Navigator initialRouteName="Home"
      screensOptions={{
        headerShown:false
      }}>
     <Stack.Screen name="Home" component={Home}/>
      <Stack.Screen name="SpaceCrafts" component={SpaceCrafts}/>
      <Stack.Screen name="DailyPic" component={DailyPic}/>
      <Stack.Screen name="StarMap" component={StarMap}/>

      </Stack.Navigator>
      </NavigationContainer>
    
    )
  }
}

      
      
      
  
    
